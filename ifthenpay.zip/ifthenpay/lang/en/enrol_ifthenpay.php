<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_ifthenpay', language 'en'.
 *
 * @package    enrol_ifthenpay
 * @copyright  1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['assignrole'] = 'Assign role';
$string['businessemail'] = 'ifthenpay business email';
$string['businessemail_desc'] = 'The email address of your business ifthenpay account';
$string['cost'] = 'Enrol cost';
$string['costerror'] = 'The enrolment cost is not numeric';
$string['costorkey'] = 'Please choose one of the following methods of enrolment.';
$string['currency'] = 'Currency';
$string['defaultrole'] = 'Default role assignment';
$string['defaultrole_desc'] = 'Select role which should be assigned to users during ifthenpay enrolments';
$string['enrolenddate'] = 'End date';
$string['enrolenddate_help'] = 'If enabled, users can be enrolled until this date only.';
$string['enrolenddaterror'] = 'Enrolment end date cannot be earlier than start date';
$string['enrolperiod'] = 'Enrolment duration';
$string['enrolperiod_desc'] = 'Default length of time that the enrolment is valid. If set to zero, the enrolment duration will be unlimited by default.';
$string['enrolperiod_help'] = 'Length of time that the enrolment is valid, starting with the moment the user is enrolled. If disabled, the enrolment duration will be unlimited.';
$string['enrolstartdate'] = 'Start date';
$string['enrolstartdate_help'] = 'If enabled, users can be enrolled from this date onward only.';
$string['expiredaction'] = 'Enrolment expiration action';
$string['expiredaction_help'] = 'Select action to carry out when user enrolment expires. Please note that some user data and settings are purged from course during course unenrolment.';
$string['mailadmins'] = 'Notify admin';
$string['mailstudents'] = 'Notify students';
$string['mailteachers'] = 'Notify teachers';
$string['messageprovider:ifthenpay_enrolment'] = 'ifthenpay enrolment messages';
$string['gatewaykey_input'] = 'ifthenpay Gateway Key';
$string['gatewaykey_title'] = 'The Gateway Key provided by ifthenpay';
$string['merchant_key'] = 'ifthenpay Merchant Key';
$string['merchant_key_desc'] = 'The Merchant Key provided by ifthenpay';
$string['antiphisingkey_passphrase_input'] = 'Anti-phishing Passphrase';
$string['antiphisingkey_passphrase_title'] = 'ANTI-PHISHING KEY TO VALIDATE PAYMENT<br><br><b>CALLBACK</b><br>The callback is required and to ativate it please click in this <a href="https://gateway.ifthenpay.com/plugins/callback/?cms=moodle" target="_blank">link</a> fill form data and click in "Ativate" button or send us an email to <a href="mailto:suporte@ifthenpay.com">suporte@ifthenpay.com</a> with your GATEWAY KEY and ANTI-PHISHING KEY and with the following subject: Callback Ativation (Moodle) ';
$string['nocost'] = 'There is no cost associated with enrolling in this course!';
$string['ifthenpay:config'] = 'Configure ifthenpay enrol instances';
$string['ifthenpay:manage'] = 'Manage enrolled users';
$string['ifthenpay:unenrol'] = 'Unenrol users from course';
$string['ifthenpay:unenrolself'] = 'Unenrol self from the course';
$string['ifthenpay_live'] = 'Live Mode';
$string['ifthenpay_test'] = 'Sandbox Mode';
$string['ifthenpay_mode'] = 'ifthenpay Mode';
$string['ifthenpay_mode_desc'] = 'Testing or Live Mode';
$string['ifthenpay_debug'] = 'Debug Mode';
$string['ifthenpay_debug_desc'] = 'Log ITN callbacks for debugging';
$string['ifthenpayaccepted'] = 'ifthenpay payments accepted';
$string['pluginname'] = 'ifthenpay';
$string['pluginname_desc'] = 'The ifthenpay module allows you to set up paid courses.  If the cost for any course is zero, then students are not asked to pay for entry.  There is a site-wide cost that you set here as a default for the whole site and then a course setting that you can set for each course individually. The course cost overrides the site cost.';
$string['sendpaymentbutton'] = 'Make the payment';
//$string['sendpaymentbutton'] = 'Send payment via ifthenpay';
$string['status'] = 'Allow ifthenpay enrolments';
$string['status_desc'] = 'Allow users to use ifthenpay to enrol into a course by default.';
$string['unenrolselfconfirm'] = 'Do you really want to unenrol yourself from course "{$a}"?';

$string['notification_email_input'] = 'E-mail for notifications';
$string['notification_email_title'] = 'E-mail for receive notifications about payment';

