<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Strings for component 'enrol_ifthenpay', language 'en'.
 *
 * @package    enrol_ifthenpay
 * @copyright  1999 onwards Martin Dougiamas  {@link http://moodle.com}
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

$string['assignrole'] = 'Atribuir papel';
$string['businessemail'] = 'E-mail da empresa';
$string['businessemail_desc'] = 'O endereço de e-mail da sua empresa';
$string['cost'] = 'Preço de inscrição';
$string['costerror'] = 'O preço de inscrição não é numérico';
$string['costorkey'] = 'Por favor, escolha um dos seguintes métodos de inscrição.';
$string['currency'] = 'Moeda';
$string['defaultrole'] = 'Atribuição de papel padrão';
$string['defaultrole_desc'] = 'Selecione o papel que deve ser atribuída aos utilizadores para inscrições pagas';
$string['enrolenddate'] = 'Data Final';
$string['enrolenddate_help'] = 'Se ativado, os utilizadores podem ser inscritos apenas até esta data.';
$string['enrolenddaterror'] = 'A data de término da inscrição não pode ser anterior à data de início';
$string['enrolperiod'] = 'Duração da inscrição';
$string['enrolperiod_desc'] = 'Período padrão de tempo em que a inscrição é válida. Se definido como zero, a duração da inscrição será ilimitada por padrão.';
$string['enrolperiod_help'] = 'Período de tempo em que a inscrição é válida, começando no momento em que o utilizador é inscrito. Se desativado, a duração da inscrição será ilimitada.';
$string['enrolstartdate'] = 'Date de Início';
$string['enrolstartdate_help'] = 'Se ativado, os utilizadores podem ser inscritos apenas a partir desta data.';
$string['expiredaction'] = 'Ação após expiração de inscrição';
$string['expiredaction_help'] = 'Selecione a ação a ser executada quando a inscrição do utilizador expirar. Observe que alguns dados e configurações do utilizador são eliminados do curso durante o cancelamento da inscrição.';
$string['mailadmins'] = 'Notificar o administrador';
$string['mailstudents'] = 'Notificar alunos';
$string['mailteachers'] = 'Notificar professores';
$string['messageprovider:ifthenpay_enrolment'] = 'ifthenpay mensagens de inscrição';
$string['gatewaykey_input'] = 'ifthenpay Gateway Key';
$string['gatewaykey_title'] = 'A Gateway Key fornecida pela ifthenpay';
$string['merchant_key'] = 'ifthenpay Chave do Comerciante';
$string['merchant_key_desc'] = 'A Chave do Comerciante fornecida pela ifthenpay';
$string['antiphisingkey_passphrase_input'] = 'Chave Anti-phishing';
$string['antiphisingkey_passphrase_title'] = 'CHAVE ANTI-PHISHING PARA VALIDAR O PAGAMENTO<br><br><b>CALLBACK</b><br>O callback é obrigatório e para ativá-lo clique neste <a href="https://gateway.ifthenpay.com/plugins/callback/?cms=moodle" target="_blank">link</a>, preencha os dados do formulário e clique no botão "Ativar" ou envie-nos um e-mail para <a href="mailto:suporte@ifthenpay.com" >suporte@ifthenpay.com</a>, com sua GATEWAY KEY e CHAVE ANTI-PHISHING e, com o seguinte assunto: Ativação de Callback (Moodle)';
$string['nocost'] = 'Não há nenhum preço associado à inscrição neste curso!';
$string['ifthenpay:config'] = 'Configure instâncias das inscrições';
$string['ifthenpay:manage'] = 'Gerir utilizadores inscritos';
$string['ifthenpay:unenrol'] = 'Cancelar inscrições do curso';
$string['ifthenpay:unenrolself'] = 'Cancelar a inscrição no curso';
$string['ifthenpay_live'] = 'Modo Real';
$string['ifthenpay_test'] = 'Modo Teste (Sandbox)';
$string['ifthenpay_mode'] = 'ifthenpay Modo';
$string['ifthenpay_mode_desc'] = 'Modo Teste or Real';
$string['ifthenpay_debug'] = 'Modo Debug';
$string['ifthenpay_debug_desc'] = 'Log ITN callbacks for debugging';
$string['ifthenpayaccepted'] = 'Pagamento aceite';
$string['pluginname'] = 'ifthenpay';
$string['pluginname_desc'] = 'O módulo ifthenpay permite receber pagamentos para cursos pagos. Se o preço de qualquer curso for zero, os utilizadores não precisam pagar pela inscrição. Há um preço aplicado ao site por defeito e um preço associado a cada curso individualmente. O preço do curso substitui o preço do site.';
$string['sendpaymentbutton'] = 'Efetuar o pagamento';
//$string['sendpaymentbutton'] = 'Efetuar o pagamento via ifthenpay';
$string['status'] = 'Permitir inscrição via ifthenpay';
$string['status_desc'] = 'Permitir que os utilizadores usem os métodos de pagamento fornecidos pela ifthenpay para se inscreverem num curso por defeito.';
$string['unenrolselfconfirm'] = 'Deseja cancelar a inscrição no curso "{$a}"?';

$string['notification_email_input'] = 'E-mail para notificações';
$string['notification_email_title'] = 'E-mail para receber notificações sobre pagamentos';

