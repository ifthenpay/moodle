<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * ifthenpay enrolments plugin settings and presets.
 *
 * @package    enrol_ifthenpay
 * @copyright  2022 ifthenpay
 * @author     ifthenpay - based on code by Petr Skoda and others
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

if ($ADMIN->fulltree) {

    //--- settings ------------------------------------------------------------------------------------------
    $settings->add(new admin_setting_heading('enrol_ifthenpay_settings', '', get_string('pluginname_desc', 'enrol_ifthenpay')));

    $settings->add(new admin_setting_configtext('enrol_ifthenpay/notification_email_input', get_string('notification_email_input', 'enrol_ifthenpay'), get_string('notification_email_title', 'enrol_ifthenpay'), '', '/^[a-zA-Z0-9-\(\)@.,_:#\/ ]*$/'));
    
    //$settings->add(new admin_setting_configtext('enrol_ifthenpay/gatewaykey_input', get_string( 'gatewaykey_input', 'enrol_ifthenpay'), get_string('gatewaykey_title', 'enrol_ifthenpay'), '', PARAM_INT));   
    $settings->add(new admin_setting_configtext('enrol_ifthenpay/gateway_key', get_string('gatewaykey_input', 'enrol_ifthenpay'), get_string('gatewaykey_title', 'enrol_ifthenpay'), '', '/^[a-zA-Z0-9-\(\)@.,_:#\/ ]*$/'));
    
    $str = rand();
    $hashedCode = hash("sha256", $str);
    $hashedCode = substr($hashedCode, 0,25);
    
    $settings->add(new admin_setting_configtext('enrol_ifthenpay/antiphishing_key', get_string('antiphisingkey_passphrase_input', 'enrol_ifthenpay'), get_string('antiphisingkey_passphrase_title', 'enrol_ifthenpay'), $hashedCode, '/^[a-zA-Z0-9-\(\)@.,_:#\/ ]*$/'));

    /*$options = array(
        'test'  => get_string('ifthenpay_test', 'enrol_ifthenpay'),
        'live'  => get_string('ifthenpay_live', 'enrol_ifthenpay')
    );
    $settings->add(new admin_setting_configselect('enrol_ifthenpay/ifthenpay_mode', get_string('ifthenpay_mode', 'enrol_ifthenpay'), get_string('ifthenpay_mode_desc', 'enrol_ifthenpay'), 'test', $options));
*/
    
   //$settings->add(new admin_setting_configcheckbox('enrol_ifthenpay/ifthenpay_debug', get_string('ifthenpay_debug', 'enrol_ifthenpay'),  get_string('ifthenpay_debug_desc', 'enrol_ifthenpay'), 1));

    $settings->add(new admin_setting_configcheckbox('enrol_ifthenpay/mailstudents', get_string('mailstudents', 'enrol_ifthenpay'), '', 0));

    $settings->add(new admin_setting_configcheckbox('enrol_ifthenpay/mailteachers', get_string('mailteachers', 'enrol_ifthenpay'), '', 0));

    $settings->add(new admin_setting_configcheckbox('enrol_ifthenpay/mailadmins', get_string('mailadmins', 'enrol_ifthenpay'), '', 0));

    // Note: let's reuse the ext sync constants and strings here, internally it is very similar,
    //       it describes what should happen when users are not supposed to be enrolled any more.
    $options = array(
        ENROL_EXT_REMOVED_KEEP           => get_string('extremovedkeep', 'enrol'),
        ENROL_EXT_REMOVED_SUSPENDNOROLES => get_string('extremovedsuspendnoroles', 'enrol'),
        ENROL_EXT_REMOVED_UNENROL        => get_string('extremovedunenrol', 'enrol'),
    );
    $settings->add(new admin_setting_configselect('enrol_ifthenpay/expiredaction', get_string('expiredaction', 'enrol_ifthenpay'), get_string('expiredaction_help', 'enrol_ifthenpay'), ENROL_EXT_REMOVED_SUSPENDNOROLES, $options));

    //--- enrol instance defaults ----------------------------------------------------------------------------
    $settings->add(new admin_setting_heading('enrol_ifthenpay_defaults',
        get_string('enrolinstancedefaults', 'admin'), get_string('enrolinstancedefaults_desc', 'admin')));

    $options = array(ENROL_INSTANCE_ENABLED  => get_string('yes'),
                     ENROL_INSTANCE_DISABLED => get_string('no'));
    $settings->add(new admin_setting_configselect('enrol_ifthenpay/status',
        get_string('status', 'enrol_ifthenpay'), get_string('status_desc', 'enrol_ifthenpay'), ENROL_INSTANCE_DISABLED, $options));

    $settings->add(new admin_setting_configtext('enrol_ifthenpay/cost', get_string('cost', 'enrol_ifthenpay'), '', 0, PARAM_FLOAT, 4));

    $ifthenpaycurrencies = enrol_get_plugin('ifthenpay')->get_currencies();
    $settings->add(new admin_setting_configselect('enrol_ifthenpay/currency', get_string('currency', 'enrol_ifthenpay'), '', 'EUR', $ifthenpaycurrencies));

    if (!during_initial_install()) {
        $options = get_default_enrol_roles(context_system::instance());
        $student = get_archetype_roles('student');
        $student = reset($student);
        $settings->add(new admin_setting_configselect('enrol_ifthenpay/roleid',
            get_string('defaultrole', 'enrol_ifthenpay'), get_string('defaultrole_desc', 'enrol_ifthenpay'), $student->id, $options));
    }

    $settings->add(new admin_setting_configduration('enrol_ifthenpay/enrolperiod',
        get_string('enrolperiod', 'enrol_ifthenpay'), get_string('enrolperiod_desc', 'enrol_ifthenpay'), 0));
}
