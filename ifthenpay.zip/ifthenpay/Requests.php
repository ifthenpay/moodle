<?php

/**
 * Description of Requests
 *
 * @author ifthenpay
 */

class Requests {
    
    /*
     * Pedido via post
     * 
     * Argumentos:
     *      $url:               endereço a qual vai ser efectuado o pedido
     *      $data:              dados a serem enviados
     *      $option_headers:    informações opcionais 
     * 
     */
    function do_post_request($url, $data, $optional_headers = null)
    {
        
        $php_errormsg = "";
        
        //$optional_headers = "Content-Type: application/x-www-form-urlencoded\r\n";
        $optional_headers = "Content-Type: application/json\r\n";
        
        $params = array('http' => array(
                    'method' => 'POST'
                    ));
        
        if ($optional_headers !== null) {
            $params['http']['header'] = $optional_headers;
        }
        
        $ctx = stream_context_create($params);
        $fp = @fopen($url, 'rb', false, $ctx);
        
        if (!$fp) {
            throw new Exception("Problem with $url - $php_errormsg");
        }
        
        $response = @stream_get_contents($fp);
        
        if ($response === false) {            
            throw new Exception("Problem reading data from $url, $php_errormsg");
        
            
        }
        
        /*print_r($response);
        die();
        
        echo $response;*/
        
        return $response;
    }
    
    /*
     * POST CURL
     */
    function do_post_curl($www,$data){
        
        $ch = curl_init($www);
        curl_setopt ($ch, CURLOPT_POST, 1);
        curl_setopt ($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        //curl_setopt ($ch, CURLOPT_FOLLOWLOCATION, 1);
        $response = curl_exec ($ch);
        curl_close ($ch);
        
        //$response = ob_get_clean();
        
        return $response;
    }
    
    /*
     * GET REQUEST
     */
    function do_get_request($url)
    {        
        $response = @file_get_contents($url, false);
                
        return $response;
    }
    
    /*
     * POST ASYNC
     */
    function post_without_wait($url, $params)
    {
        
        $post_params = array();
        
        foreach ($params as $key => &$val) {
          if (is_array($val)) $val = implode(',', $val);
            $post_params[] = $key.'='.urlencode($val);
        }
        $post_string = implode('&', $post_params);

        $parts=parse_url($url);

        $fp = fsockopen($parts['host'],
            isset($parts['port'])?$parts['port']:80,
            $errno, $errstr, 30);

        $out = "POST ".$parts['path']." HTTP/1.1\r\n";
        $out.= "Host: ".$parts['host']."\r\n";
        $out.= "Content-Type: application/json\r\n";
        $out.= "Content-Length: ".strlen($post_string)."\r\n";
        $out.= "Connection: Close\r\n\r\n";
        if (isset($post_string)) $out.= $post_string;

        fwrite($fp, $out);
        fclose($fp);
    }

    
    function callJSON($method, $url, $data){
        
        
       $curl = curl_init();
       switch ($method){
          case "POST":
             curl_setopt($curl, CURLOPT_POST, 1);
             if ($data)
                curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
             break;
          case "PUT":
             curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
             if ($data)
                curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
             break;
          default:
             if ($data)
                $url = sprintf("%s?%s", $url, http_build_query($data));
       }
       // OPTIONS:
       curl_setopt($curl, CURLOPT_URL, $url);
       curl_setopt($curl, CURLOPT_HTTPHEADER, array(
          'Content-Type: application/json',
       ));
       curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
       curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
       // EXECUTE:
       $result = curl_exec($curl);
       if(!$result){die("Connection Failure");}
       curl_close($curl);
       
       /*echo $result;
       die();*/
       return $result;
    }    
    
    function callGatewayJSON($method, $url, $data){
        
        /*echo $method;
        echo $url;
        print_r($data);*/
        
       $curl = curl_init();
       switch ($method){
          case "POST":
             curl_setopt($curl, CURLOPT_POST, 1);
             if ($data)
                curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($data));
             break;
          case "PUT":
             curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
             if ($data)
                curl_setopt($curl, CURLOPT_POSTFIELDS, $data);			 					
             break;
          default:
             if ($data)
                $url = sprintf("%s?%s", $url, http_build_query($data));
       }
       // OPTIONS:
       curl_setopt($curl, CURLOPT_URL, $url);
       curl_setopt($curl, CURLOPT_HTTPHEADER, array(
          'Content-Type: application/json',
       ));
       curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
       curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
       // EXECUTE:
       $result = curl_exec($curl);
       if(!$result){die("Connection Failure");}
       curl_close($curl);

       /*echo "Terminou a chamada";
       die();*/
       /*echo $result;
       die();*/
       return $result;
    }      
    
}

?>
