<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Listens for Instant Payment Notification from ifthenpay
 *
 * This script waits for Payment notification from ifthenpay,
 * then double checks that data by sending it back to ifthenpay.
 * If ifthenpay verifies this then it sets up the enrolment for that
 * user.
 *
 * @package    enrol_ifthenpay
 * @copyright 2022 ifthenpay
 * @author     ifthenpay - based on code by others
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

// Disable moodle specific debug messages and any errors in output,
// comment out when debugging or better look into error log!
define('NO_DEBUG_DISPLAY', false);

require("../../config.php");
require_once("lib.php");
//require_once($CFG->libdir.'/eventslib.php');
require_once($CFG->libdir.'/enrollib.php');
require_once($CFG->libdir . '/filelib.php');
require_once( "ifthenpay_common.inc" );
require_once("Requests.php");

// ifthenpay does not like when we return error messages here,
// the custom handler just logs exceptions and stops.
set_exception_handler('enrol_ifthenpay_itn_exception_handler');



/// Keep out casual intruders
if (empty( $_GET) )
{
    show_error("Sorry, you can not use the script that way.");
}else{
    if(!isset($_GET["uid"]) && !isset($_GET["apk"]) && !isset($_GET["amt"]) && !isset($_GET["oid"]) && !isset($_GET["payment_method"]) && !isset($_GET["payment_datetime"])){
        show_error("Sorry, you can not use the script that way.");
    }else{
        //Replace vars
        str_replace("[ANTI_PHISHING_KEY]","",  $_GET["apk"]);
        str_replace("[ORDER_ID]","",  $_GET["oid"]);
        str_replace("[AMOUNT]","0",$_GET["amt"]);
        str_replace("[PAYMENT_METHOD]","",  $_GET["pmt"]);
        str_replace("[PAYMENT_DATETIME]","",$_GET["pdt"]);                   
        
        //Payment method
        $_GET["payment_method"] = $_GET["pmt"];
        
    }
}



$tld = 'com';
$plugin = enrol_get_plugin('ifthenpay');
define( 'PF_DEBUG', $plugin->get_config( 'ifthenpay_debug' ) );

$pfError = false;
$pfErrMsg = '';
$pfDone = false;
$pfData = array();
$pfParamString = '';

pflog( 'ifthenpay callback received' );
$data = new stdClass();

$dataWS = GetDataWS($_GET["uid"]);



if(strtoupper($dataWS->cms)!="MOODLE"){
    show_error("Sorry, you can not use the script that way.");
}


//verify data - query string
if(!VerifyDataQueryStringValues($_GET, $dataWS)){
    show_error("Sorry, you can not use the script that way (invalid values).");
}

$data->m_payment_id = $dataWS->orderId;


$custom = explode( '-', $data->m_payment_id );
$data->userid           = (int)$custom[0];
$data->courseid         = (int)$custom[1];
$data->instanceid       = (int)$custom[2];
$data->payment_currency = 'EUR';
$data->timeupdated      = time();

$data->pf_payment_id    = $_GET["uid"];
$data->payment_method   = $_GET["payment_method"];
$data->payment_status   = "COMPLETE";
$data->item_name        = $dataWS->itemName;
$data->item_description = $dataWS->orderDescription;
$data->amount_gross     = $dataWS->amount;
$data->amount_fee       = 0;
$data->amount_net       = $dataWS->amount;
$data->name_first       = $dataWS->firstName;
$data->name_last        = $dataWS->lastName;
$data->email_address    = $dataWS->email;
$data->gateway_key      = $dataWS->gatewayKey;
$data->antiphishing_key = $dataWS->antiphishingKey;
$data->signature        = $dataWS->signature;

/// get the user and course records

if (! $user = $DB->get_record( "user", array( "id" => $data->userid ) ) )
{
    $pfError = true;
    $pfErrMsg .= "Not a valid user id \n";
}

if (! $course = $DB->get_record( "course", array( "id" => $data->courseid ) ) )
{
    $pfError = true;
    $pfErrMsg .= "Not a valid course id \n";
}

if (! $context = context_course::instance( $course->id, IGNORE_MISSING ) )
{
    $pfError = true;
    $pfErrMsg .= "Not a valid context id \n";
}

if (! $plugin_instance = $DB->get_record( "enrol", array( "id" => $data->instanceid, "status"=>0 ) ) )
{
    $pfError = true;
    $pfErrMsg .= "Not a valid instance id \n";
}


//// Notify ifthenpay that information has been received
if( !$pfError && !$pfDone )
{
    header( 'HTTP/1.0 200 OK' );
    flush();
}
//// Get data sent by ifthenpay
if( !$pfError && !$pfDone )
{
    pflog( 'Get posted data' );
    
    // Posted variables from ITN
    //$pfData = pfGetData($dataWS);
    $pfData['item_name'] = html_entity_decode( $dataWS->itemName);
    $pfData['item_description'] = html_entity_decode( $dataWS->orderDescription);
    $pfData['signature'] = $dataWS->signature;
    $pfData['amount_gross'] = $dataWS->amount;    
    $pfData['payment_status'] = $data->payment_status;
    
    pflog( 'ifthenpay Data: '. print_r( $pfData, true ) );
    
    //if( $pfData === false )
    if(sizeof( $dataWS ) == 0)
    {
        $pfError = true;
        $pfErrMsg = PF_ERR_BAD_ACCESS;
    }
}

//// Verify security signature
if( !$pfError && !$pfDone )
{
    pflog( 'Verify security signature' );
    $passphrase = $plugin->get_config( 'antiphishing_key' );    
        
    //echo "passphrase: ".$passphrase;
    
    $pfPassphrase = null;
    if(!empty( $passphrase )){
        $pfPassphrase = $dataWS->antiphishingKey;    
    }
        
    $pfParamString = "gateway_key=".$dataWS->gatewayKey;
    
    //$pfPassphrase = $plugin->get_config( 'ifthenpay_mode' ) == 'test' ? null : ( !empty( $passphrase ) ? $passphrase : null );
    // If signature different, log for debugging
    if( !pfValidSignature( $pfData, $pfParamString, $pfPassphrase ) )
    {
        $pfError = true;
        $pfErrMsg = PF_ERR_INVALID_SIGNATURE;
    }
}


//// Verify source IP (If not in debug mode)
/*if( !$pfError && !$pfDone && !PF_DEBUG )
{
    pflog( 'Verify source IP' );

    if( !pfValidIP( $_SERVER['REMOTE_ADDR'] ) )
    {
        $pfError = true;
        $pfErrMsg = PF_ERR_BAD_SOURCE_IP;
    }
}*/



//// Verify data received
if( !$pfError )
{
    pflog( 'Verify data received' );

    $pfHost = 'gateway.ifthenpay.' . $tld;  //( $plugin->get_config( 'ifthenpay_mode' ) == 'live' ? 'www' : 'sandbox'  ) . '.ifthenpay.' . $tld;
    
    $pfValid = pfValidData( $pfHost, $pfParamString );
    
    if( !$pfValid )
    {
        $pfError = true;
        $pfErrMsg = PF_ERR_BAD_ACCESS;
    }
    
    
}


//// Check data against internal order
if( !$pfError && !$pfDone )
{
    pflog( 'Check data against internal order' );

    if ( (float) $plugin_instance->cost <= 0 ) {
        $cost = (float) $plugin->get_config('cost');
    } else {
        $cost = (float) $plugin_instance->cost;
    }


    
    $cost = format_float( $cost, 2, false );    
    // Check order amount
    if( !pfAmountsEqual( $pfData['amount_gross'], $cost ) )
    {
        $pfError = true;
        $pfErrMsg = PF_ERR_AMOUNT_MISMATCH;
    }
}


if( !$pfError && !$pfDone )
{
    
    //print_r($data);
    //die();
    if ( $existing = $DB->get_record( "enrol_ifthenpay", array( "pf_payment_id" => $data->pf_payment_id ) ) )
    {   // Make sure this transaction doesn't exist already
        $pfErrMsg .= "Transaction $data->pf_payment_id is being repeated! \n" ;
        $pfError = true;
    }
    if ( $data->payment_currency != $plugin_instance->currency )
    {
        $pfErrMsg .= "Currency does not match course settings, received: " . $data->mc_currency . "\n";
        $pfError = true;
    }

    if ( !$user = $DB->get_record( 'user', array( 'id' => $data->userid ) ) )
    {   // Check that user exists
        $pfErrMsg .= "User $data->userid doesn't exist \n";
        $pfError = true;
    }

    if ( !$course = $DB->get_record( 'course', array( 'id'=> $data->courseid ) ) )
    { // Check that course exists
        $pfErrMsg .= "Course $data->courseid doesn't exist \n";
        $pfError = true;
    }
}



//// Check status and update order
if( !$pfError && !$pfDone )
{
    pflog( 'Check status and update order' );


    switch( $pfData['payment_status'] )
    {
        case 'COMPLETE':
            pflog( '- Complete' );

            $coursecontext = context_course::instance($course->id, IGNORE_MISSING);


            if ($plugin_instance->enrolperiod) {
                $timestart = time();
                $timeend   = $timestart + $plugin_instance->enrolperiod;
            } else {
                $timestart = 0;
                $timeend   = 0;
            }

            // Enrol user
            $plugin->enrol_user($plugin_instance, $user->id, $plugin_instance->roleid, $timestart, $timeend);

            // Pass $view=true to filter hidden caps if the user cannot see them
            if ($users = get_users_by_capability($context, 'moodle/course:update', 'u.*', 'u.id ASC',
                '', '', '', '', false, true)) {
                $users = sort_by_roleassignment_authority($users, $context);
                $teacher = array_shift($users);
            } else {
                $teacher = false;
            }

            $mailstudents = $plugin->get_config('mailstudents');
            $mailteachers = $plugin->get_config('mailteachers');
            $mailadmins   = $plugin->get_config('mailadmins');
            $shortname = format_string($course->shortname, true, array('context' => $context));


            if (!empty($mailstudents)) {
                $a = new stdClass();
                $a->coursename = format_string($course->fullname, true, array('context' => $coursecontext));
                $a->profileurl = "$CFG->wwwroot/user/view.php?id=$user->id";

                $eventdata = new stdClass();
                $eventdata->modulename        = 'moodle';
                $eventdata->component         = 'enrol_ifthenpay';
                $eventdata->name              = 'ifthenpay_enrolment';
                $eventdata->userfrom          = empty($teacher) ? get_admin() : $teacher;
                $eventdata->userto            = $user;
                $eventdata->subject           = get_string("enrolmentnew", 'enrol', $shortname);
                $eventdata->fullmessage       = get_string('welcometocoursetext', '', $a);
                $eventdata->fullmessageformat = FORMAT_PLAIN;
                $eventdata->fullmessagehtml   = '';
                $eventdata->smallmessage      = '';
                message_send($eventdata);

            }

            if (!empty($mailteachers) && !empty($teacher)) {
                $a->course = format_string($course->fullname, true, array('context' => $coursecontext));
                $a->user = fullname($user);

                $eventdata = new stdClass();
                $eventdata->modulename        = 'moodle';
                $eventdata->component         = 'enrol_ifthenpay';
                $eventdata->name              = 'ifthenpay_enrolment';
                $eventdata->userfrom          = $user;
                $eventdata->userto            = $teacher;
                $eventdata->subject           = get_string("enrolmentnew", 'enrol', $shortname);
                $eventdata->fullmessage       = get_string('enrolmentnewuser', 'enrol', $a);
                $eventdata->fullmessageformat = FORMAT_PLAIN;
                $eventdata->fullmessagehtml   = '';
                $eventdata->smallmessage      = '';
                message_send($eventdata);
            }

            if ( !empty( $mailadmins ) )
            {
                $a->course = format_string($course->fullname, true, array('context' => $coursecontext));
                $a->user = fullname($user);
                $admins = get_admins();
                foreach ($admins as $admin) {
                    $eventdata = new stdClass();
                    $eventdata->modulename        = 'moodle';
                    $eventdata->component         = 'enrol_ifthenpay';
                    $eventdata->name              = 'ifthenpay_enrolment';
                    $eventdata->userfrom          = $user;
                    $eventdata->userto            = $admin;
                    $eventdata->subject           = get_string("enrolmentnew", 'enrol', $shortname);
                    $eventdata->fullmessage       = get_string('enrolmentnewuser', 'enrol', $a);
                    $eventdata->fullmessageformat = FORMAT_PLAIN;
                    $eventdata->fullmessagehtml   = '';
                    $eventdata->smallmessage      = '';
                    message_send($eventdata);
                }
            }
            $DB->insert_record("enrol_ifthenpay", $data );


            break;

        case 'FAILED':
            pflog( '- Failed' );

            break;

        case 'PENDING':
            pflog( '- Pending' );

            $eventdata = new stdClass();
            $eventdata->modulename        = 'moodle';
            $eventdata->component         = 'enrol_ifthenpay';
            $eventdata->name              = 'ifthenpay_enrolment';
            $eventdata->userfrom          = get_admin();
            $eventdata->userto            = $user;
            $eventdata->subject           = "Moodle: ifthenpay payment";
            $eventdata->fullmessage       = "Your ifthenpay payment is pending.";
            $eventdata->fullmessageformat = FORMAT_PLAIN;
            $eventdata->fullmessagehtml   = '';
            $eventdata->smallmessage      = '';
            message_send($eventdata);

            message_ifthenpay_error_to_admin("Payment pending", $data );

            break;

        default:
            // If unknown status, do nothing (safest course of action)
            break;
    }

}
else
{
    //$DB->insert_record( "enrol_ifthenpay", $data, false);
    message_ifthenpay_error_to_admin( "Received an invalid payment notification!! (Fake payment?)\n" . $pfErrMsg, $data);
    die( 'ERROR encountered, view the logs to debug.' );
}

exit;


//--- HELPER FUNCTIONS --------------------------------------------------------------------------------------


function message_ifthenpay_error_to_admin($subject, $data) {
    echo $subject;
    $admin = get_admin();
    $site = get_site();

    $message = "$site->fullname:  Transaction failed.\n\n$subject\n\n";

    foreach ($data as $key => $value) {
        $message .= "$key => $value\n";
    }

    $eventdata = new stdClass();
    $eventdata->modulename        = 'moodle';
    $eventdata->component         = 'enrol_ifthenpay';
    $eventdata->name              = 'ifthenpay_enrolment';
    $eventdata->userfrom          = $admin;
    $eventdata->userto            = $admin;
    $eventdata->subject           = "ifthenpay ERROR: ".$subject;
    $eventdata->fullmessage       = $message;
    $eventdata->fullmessageformat = FORMAT_PLAIN;
    $eventdata->fullmessagehtml   = '';
    $eventdata->smallmessage      = '';
    pflog( 'Error To Admin: ' . print_r( $eventdata, true ) );
    message_send($eventdata);

}

/**
 * Silent exception handler.
 *
 * @param Exception $ex
 * @return void - does not return. Terminates execution!
 */
function enrol_ifthenpay_itn_exception_handler($ex) {
    $info = get_exception_info($ex);

    $logerrmsg = "enrol_ifthenpay ITN exception handler: ".$info->message;
    $logerrmsg .= ' Debug: '.$info->debuginfo."\n".format_backtrace($info->backtrace, true);

    error_log($logerrmsg);

    exit(0);
}


/*GET DATA*/
function GetDataWS($uid){                


    $request = new Requests();                        

    //$wsURL = "https://ifthenpay-api.ngrok.io/gateway/plugins/transaction/get?id=".$uid;
    $wsURL = "https://ifthenpay.com/api/gateway/plugins/transaction/get?id=".$uid;
    
    $response = $request->do_get_request($wsURL);
    
   
    $response = str_replace("\"{", "{", $response);
    $response = str_replace("}\"", "}", $response);
    $response = str_replace("\\", "", $response);

    return json_decode($response);
}  

/*VERIFY DATA QUERY STRING WITH VALUES IN WS*/
function VerifyDataQueryStringValues($get, $dataWS){
    $isValid = true;
        
   
    if($get["payment_method"]=="CCARD"){
        if($get["id"]!=$dataWS->orderId){
            $isValid = false;    
        }elseif(number_format($get["amount"], 2, '.', '')!=number_format($dataWS->amount, 2, '.', '')){
            $isValid = false;  
        }
    }else{
        if($get["apk"]!=$dataWS->antiphishingKey){
            $isValid = false;    
        }elseif($get["oid"]!=$dataWS->orderId){
            $isValid = false;    
        }elseif(number_format($get["amt"], 2, '.', '')!=number_format($dataWS->amount, 2, '.', '')){
            $isValid = false;  
        }        
        
    }
    


    
    return $isValid;
}

function show_error($message){
    echo $message;
    exit;
}